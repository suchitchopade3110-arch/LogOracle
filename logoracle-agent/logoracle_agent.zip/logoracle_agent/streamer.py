"""logoracle_agent/streamer.py — HTTP streamer to LogOracle backend."""
import threading
import httpx


class Streamer:
    def __init__(self, base_url: str, mode: str = "tech", dev_id: str = ""):
        self.base_url        = base_url
        self.mode            = mode
        self.dev_id          = dev_id
        self.lines_sent      = 0
        self.analyses_done   = 0
        self.critical_count  = 0
        self.warning_count   = 0
        self.last_finding    = None
        self._lock           = threading.Lock()
        self._buffer: list[str] = []
        self._client         = httpx.Client(timeout=10.0)

    def ingest(self, lines: list[str], source: str = "agent"):
        """Receive new log lines, buffer them, flush to backend."""
        with self._lock:
            self._buffer.extend(lines)
            self.lines_sent += len(lines)

        # Send to /ingest/logs immediately
        try:
            self._client.post(
                f"{self.base_url}/ingest/logs",
                json={"lines": lines, "source": source},
            )
        except Exception:
            pass

        # Analyze every 20+ lines
        with self._lock:
            if len(self._buffer) < 20:
                return
            batch = self._buffer[:]
            self._buffer.clear()

        threading.Thread(target=self._analyze, args=(batch,), daemon=True).start()

    def _analyze(self, lines: list[str]):
        """POST to /analyze/log, update counters."""
        try:
            r = self._client.post(
                f"{self.base_url}/analyze/log",
                json={
                    "log_text":   "\n".join(lines),
                    "redact_pii": True,
                    "mode":       self.mode,
                },
            )
            if r.status_code == 200:
                data = r.json()
                findings = data.get("security_findings", [])
                with self._lock:
                    self.analyses_done += 1
                    self.critical_count += sum(1 for f in findings if f.get("severity") == "CRITICAL")
                    self.warning_count  += sum(1 for f in findings if f.get("severity") == "WARNING")
                    if findings:
                        self.last_finding = findings[0].get("message", "")[:60]
        except Exception:
            pass
