"""
logoracle_agent/main.py
LogOracle local agent — tails log files, monitors system, streams to backend.

Install: pip install logoracle-agent
Run:     logoracle-agent --url http://localhost:8001 --watch /var/log/syslog
"""
import os
import sys
import time
import socket
import threading
import click
import httpx
import psutil
from rich.console import Console
from rich.live    import Live
from rich.table   import Table
from rich.text    import Text
from rich         import print as rprint

from logoracle_agent.watcher  import LogWatcher
from logoracle_agent.streamer import Streamer
from logoracle_agent.monitor  import SystemMonitor
from logoracle_agent.relay    import HealRelay
from logoracle_agent.api_monitor import APIMonitor

console = Console()


@click.command()
@click.option("--url",     default="http://localhost:8001", help="LogOracle backend URL", show_default=True)
@click.option("--watch",   multiple=True, help="Log file path(s) to tail. Can use multiple times.")
@click.option("--mode",    default="tech", type=click.Choice(["tech","plain"]), show_default=True)
@click.option("--dev-id",  default="", help="Your developer ID for XP tracking")
@click.option("--interval",default=2.0,  help="Flush interval in seconds", show_default=True)
@click.option("--perf",    is_flag=True, default=False, help="Also monitor CPU/RAM/disk")
@click.option("--api",     is_flag=True, default=False, help="Monitor outgoing HTTP via proxy (experimental)")
@click.option("--api-port", default=8888, help="Local proxy port for API monitoring", show_default=True)
@click.option("--relay",   is_flag=True, default=False, help="Enable heal command relay for approved remote fixes")
@click.option("--agent-id", default="", help="Unique relay agent ID; auto-generated if omitted")
@click.option("--dry-run", is_flag=True, default=False, help="Relay dry-run: receive commands but do not execute them")
def cli(url, watch, mode, dev_id, interval, perf, api, api_port, relay, agent_id, dry_run):
    """
    LogOracle Local Agent

    Tails log files, monitors system resources, and streams findings
    to the LogOracle backend in real time.

    With --relay, the agent also polls for approved heal commands and
    executes them locally after validating a local whitelist.

    With --api, the agent starts a local proxy and monitors outgoing HTTP.

    Examples:

        logoracle-agent --watch /var/log/syslog

        logoracle-agent --watch /var/log/auth.log --watch /var/log/nginx/error.log --perf

        logoracle-agent --url https://my-logoracle.onrender.com --watch /var/log/syslog

        logoracle-agent --watch /var/log/syslog --relay --agent-id prod-server-01

        logoracle-agent --watch /var/log/syslog --api --api-port 8888
    """
    console.print(f"\n[bold cyan]LogOracle Agent[/bold cyan] v0.1.0")
    console.print(f"Backend: [green]{url}[/green]")

    # Health check
    try:
        r = httpx.get(f"{url}/health", timeout=5)
        if r.status_code == 200:
            console.print(f"[green]✓ Backend connected[/green]")
        else:
            console.print(f"[red]✗ Backend returned {r.status_code}[/red]")
            sys.exit(1)
    except Exception as e:
        console.print(f"[red]✗ Cannot reach backend: {e}[/red]")
        console.print(f"[yellow]Start backend: uvicorn main:app --port 8001[/yellow]")
        sys.exit(1)

    if not agent_id:
        agent_id = f"{socket.gethostname()}_{int(time.time()) % 10000}"

    # Resolve log paths
    paths = list(watch)
    if not paths:
        # Auto-detect common log files
        candidates = [
            "/var/log/syslog",
            "/var/log/auth.log",
            "/var/log/kern.log",
            "/var/log/messages",
        ]
        paths = [p for p in candidates if os.path.exists(p)]
        if paths:
            console.print(f"[yellow]Auto-detected log files:[/yellow] {', '.join(paths)}")
        else:
            console.print("[yellow]No log files specified or auto-detected. Use --watch /path/to/log[/yellow]")

    streamer = Streamer(url, mode, dev_id)

    if relay:
        _register_relay_agent(url, agent_id, paths)

    # Start log watchers
    watchers = []
    for path in paths:
        if not os.path.exists(path):
            console.print(f"[yellow]⚠ File not found: {path}[/yellow]")
            continue
        w = LogWatcher(path, streamer, interval)
        w.start()
        watchers.append(w)
        console.print(f"[green]✓ Watching:[/green] {path}")

    # Start perf monitor
    monitor = None
    if perf:
        monitor = SystemMonitor(streamer, poll_interval=5.0)
        monitor.start()
        console.print("[green]✓ System monitoring active[/green]")

    # Start heal relay
    heal_relay = None
    if relay:
        console.print(f"Relay agent ID: [cyan]{agent_id}[/cyan]")
        heal_relay = HealRelay(url, agent_id, dry_run=dry_run)
        heal_relay.start()

    # Start API monitor
    api_monitor = None
    if api:
        api_monitor = APIMonitor(url, proxy_port=api_port)
        api_monitor.start()
        console.print(f"[green]✓ API Agent active[/green] on proxy port {api_port}")
        console.print(f"[dim]  export HTTP_PROXY=http://localhost:{api_port}[/dim]")

    console.print("\n[bold]Active agents:[/bold]")
    console.print("  Log Agent      ✅")
    console.print("  Security Agent ✅ (via log analysis)")
    console.print(f"  Perf Agent     {'✅' if perf else '□ (add --perf)'}")
    console.print(f"  Heal Relay     {'✅' if relay else '□ (add --relay)'}")
    console.print(f"  API Agent      {'✅' if api else '□ (add --api)'}")
    console.print("\n[dim]Press Ctrl+C to stop[/dim]\n")

    # Live dashboard
    try:
        with Live(console=console, refresh_per_second=1) as live:
            while True:
                live.update(_build_dashboard(streamer, paths, perf, heal_relay, api_monitor))
                time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        for w in watchers:
            w.stop()
        if monitor:
            monitor.stop()
        if heal_relay:
            heal_relay.stop()
        if api_monitor:
            api_monitor.stop()
        console.print("\n[yellow]LogOracle agent stopped.[/yellow]")


def _register_relay_agent(url: str, agent_id: str, paths: list[str]):
    try:
        httpx.post(
            f"{url}/heal/relay/register",
            json={
                "agent_id": agent_id,
                "hostname": socket.gethostname(),
                "platform": _detect_platform(),
                "watch_paths": paths,
            },
            timeout=5,
        )
        console.print("[green]✓ Relay agent registered[/green]")
    except Exception as exc:
        console.print(f"[yellow]⚠ Could not register relay agent: {exc}[/yellow]")


def _detect_platform() -> str:
    import platform

    system = platform.system().lower()
    if "linux" in system:
        return "linux"
    if "darwin" in system:
        return "macos"
    if "windows" in system:
        return "windows"
    return "unknown"


def _build_dashboard(streamer, paths, perf, relay=None, api_monitor=None) -> Table:
    table = Table(show_header=True, header_style="bold cyan", expand=True)
    table.add_column("Metric", style="dim", width=20)
    table.add_column("Value")

    table.add_row("Lines sent",  str(streamer.lines_sent))
    table.add_row("Analyses",    str(streamer.analyses_done))
    table.add_row("Findings",    f"[red]{streamer.critical_count} CRITICAL[/red]  "
                                  f"[yellow]{streamer.warning_count} WARNING[/yellow]")
    table.add_row("Last finding", streamer.last_finding or "—")

    if relay:
        table.add_row("Heal relay", "[yellow]dry-run[/yellow]" if relay.dry_run else "[green]active[/green]")
        table.add_row("Commands run", str(relay.executed))
        table.add_row("Relay failed", str(relay.failed))

    if api_monitor:
        table.add_row("API proxy", f"localhost:{api_monitor.proxy_port}")
        table.add_row("API events pending", str(api_monitor.pending_count()))
        table.add_row("API analyses", str(api_monitor.analyses))
        table.add_row("API findings", str(api_monitor.findings))
        if api_monitor.last_finding:
            table.add_row("API last finding", api_monitor.last_finding)

    if perf:
        try:
            cpu  = psutil.cpu_percent()
            ram  = psutil.virtual_memory().percent
            disk = psutil.disk_usage("/").percent
            table.add_row("CPU",  f"{'[red]' if cpu>85 else ''}{cpu:.1f}%{'[/red]' if cpu>85 else ''}")
            table.add_row("RAM",  f"{'[red]' if ram>85 else ''}{ram:.1f}%{'[/red]' if ram>85 else ''}")
            table.add_row("Disk", f"{'[red]' if disk>90 else ''}{disk:.1f}%{'[/red]' if disk>90 else ''}")
        except Exception:
            pass

    return table


if __name__ == "__main__":
    cli()
