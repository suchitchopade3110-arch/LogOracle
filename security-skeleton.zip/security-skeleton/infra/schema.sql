-- infra/schema.sql
-- Core security tables — run once on fresh DB

-- Extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;  -- for gen_random_uuid()

-- ─────────────────────────────────────────────
-- Users table — hashed passwords, role, lock support
CREATE TABLE IF NOT EXISTS users (
  id             SERIAL PRIMARY KEY,
  email          VARCHAR(255) UNIQUE NOT NULL,
  password_hash  TEXT NOT NULL,               -- argon2id hash only
  role           VARCHAR(50) DEFAULT 'user',  -- user | admin | honeytoken
  mfa_secret     TEXT,                        -- TOTP secret (encrypted)
  mfa_enabled    BOOLEAN DEFAULT false,
  locked         BOOLEAN DEFAULT false,
  lock_reason    VARCHAR(100),
  failed_attempts INT DEFAULT 0,
  last_login_at  TIMESTAMPTZ,
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  updated_at     TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast email lookup
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ─────────────────────────────────────────────
-- Sessions table — track active sessions, revoke on incident
CREATE TABLE IF NOT EXISTS sessions (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    INT REFERENCES users(id) ON DELETE CASCADE,
  ip_address INET,
  user_agent TEXT,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- ─────────────────────────────────────────────
-- Audit log — every security event, immutable
CREATE TABLE IF NOT EXISTS audit_log (
  id           BIGSERIAL PRIMARY KEY,
  user_id      INT,  -- nullable (pre-auth events)
  action       VARCHAR(100) NOT NULL,
  target_table VARCHAR(100),
  ip_address   INET,
  meta         JSONB,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Partition by month if high volume
CREATE INDEX IF NOT EXISTS idx_audit_user   ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_time   ON audit_log(created_at);

-- Prevent row deletion from audit log (security policy)
-- ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
-- CREATE POLICY audit_insert_only ON audit_log FOR SELECT, INSERT;

-- ─────────────────────────────────────────────
-- Blocked IPs — app-level block list
CREATE TABLE IF NOT EXISTS blocked_ips (
  ip         INET PRIMARY KEY,
  reason     VARCHAR(100),
  blocked_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ  -- NULL = permanent
);

-- ─────────────────────────────────────────────
-- Honeytokens seeded via honeytoken.js on startup
-- Rows with role='honeytoken' — any access triggers alert

-- ─────────────────────────────────────────────
-- Minimal DB user — app only gets what it needs
-- Run as superuser once:
--
-- CREATE ROLE app_user LOGIN PASSWORD 'STRONG_PASS';
-- GRANT SELECT, INSERT, UPDATE ON users, sessions, audit_log, blocked_ips TO app_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;
-- REVOKE DELETE ON audit_log FROM app_user;  -- audit log = append only
