// src/config/secrets.js
// Secrets from HashiCorp Vault or .env — NEVER hardcoded

const vault = require('node-vault'); // optional: only if using Vault

let secretsCache = {};

async function loadFromVault() {
  const client = vault({ endpoint: process.env.VAULT_ADDR, token: process.env.VAULT_TOKEN });
  const result = await client.read('secret/data/db');
  secretsCache = result.data.data;
}

function get(key) {
  // Vault takes priority, fallback to env
  const val = secretsCache[key] || process.env[key];
  if (!val) throw new Error(`[SECRETS] Missing required secret: ${key}`);
  return val;
}

function getOptional(key) {
  return secretsCache[key] || process.env[key] || '';
}

module.exports = { loadFromVault, get, getOptional };
