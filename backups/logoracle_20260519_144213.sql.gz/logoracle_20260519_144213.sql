--
-- PostgreSQL database dump
--

\restrict m5451HjQVulb2Pb3AUfxAduZtPtC56cEHDsJpgt7RMoU3juxF4ZluSSUa4jQFl5

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict m5451HjQVulb2Pb3AUfxAduZtPtC56cEHDsJpgt7RMoU3juxF4ZluSSUa4jQFl5

